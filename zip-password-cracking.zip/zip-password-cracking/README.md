# zip-password-cracking
This repository provides resources for understanding password cracking for Zip files and other compressed formats. It includes tools and notes for reference.
